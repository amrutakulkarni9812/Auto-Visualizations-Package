# TODO: Fill out this file with information about your package

from setuptools import setup

# HINT: Go back to the object-oriented programming lesson "Putting Code on PyPi" and "Exercise: Upload to PyPi"

setup(name = 'auto_visualizations',
      version = '0.3',
      description = 'Data Visualization',
      packages = ['auto_visualizations'],
      zip_safe = False
     )

# HINT: Here is an example of a setup.py file
# https://packaging.python.org/tutorials/packaging-projects/